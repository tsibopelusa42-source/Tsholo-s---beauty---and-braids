TSHOLO'S BEAUTY AND BRAIDS WEBSITE
==================================

Files:
- index.html       Main website page
- style.css        Layout, colours, fonts and responsive design
- script.js        Mobile menu and automatic copyright year
- images/          Supplied reference images and cropped hairstyle gallery photos

HOW TO OPEN IN NETBEANS
1. Extract the ZIP file to a folder on your computer.
2. Open NetBeans.
3. Choose File > Open Project if NetBeans recognises the folder as a project. This is a static HTML website, so if it is not listed as a project:
   - Choose File > New Project.
   - Choose HTML5/JavaScript > HTML5/JS Application (wording can vary by NetBeans version).
   - Choose No Site Template.
   - Create the project, then copy index.html, style.css, script.js and the images folder into the project folder, replacing any starter files if prompted.
4. Open index.html and run it using your browser, or right-click index.html and choose Run File.
5. Keep the images folder beside index.html so the gallery photos load correctly.

IMPORTANT DETAILS
- WhatsApp booking links use 060 722 2509.
- Prices, opening hours, booking fee and location are based on the information in the supplied salon images.
- This is a front-end website. The Book buttons open WhatsApp; the site does not yet store appointments in a database or take payments online.
- Before publishing, double-check all prices and booking policies with the salon owner.
